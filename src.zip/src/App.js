import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
        <h1>Жадыра Амангалиева</h1>
        <p>Город проживания: Атырау</p>
    </div>
  );
}

export default App;
